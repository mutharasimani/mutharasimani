import { Input, Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { UserService } from './service/user.service';

import { ActivatedRoute, Router, Params } from '@angular/router';
import { first } from 'rxjs/operators';


@Component({
  selector: 'app-login-form',
  templateUrl: 'login.component.html',
  styleUrls: ['login.component.css']

})
export class LoginComponent implements OnInit{
  returnUrl: string;
  loading = false;
  @Input() error: string | null;

  form: FormGroup = new FormGroup({
    username: new FormControl('', [Validators.required]),
    password: new FormControl('', [Validators.required]),
  });

  constructor(private userService: UserService, private route: ActivatedRoute, private router: Router) { }
  ngOnInit() {

    this.returnUrl = this.route.snapshot.queryParams.returnUrl || '/';
    console.log('this.returnUrl...' + this.returnUrl);
  }
  get f() { return this.form.controls; }

  submit() {

    if (this.form.valid) {
      this.userService.login(this.f.username.value, this.f.password.value)
        .subscribe(
          data => {
            this.error = '';
            if (
              data[0] &&
              data[0].username === this.f.username.value &&
              data[0].password === this.f.password.value
            ) {
              console.log('condition match');
              this.returnUrl = '/home';
              this.router.navigate([this.returnUrl]);
            }
            else {
              this.error = 'Invalid login details';
            }
          });
    }
  }

}
