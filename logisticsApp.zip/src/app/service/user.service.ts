import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { BehaviorSubject, Observable } from 'rxjs';
import { User } from '../models/user';
import { map } from 'rxjs/operators';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  private usersUrl = 'http://localhost:3001/users';
  private userSubject: BehaviorSubject<User>;
  public user: Observable<User>;
  private httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    })
  };

  constructor(private router: Router, private http: HttpClient) {
    this.userSubject = new BehaviorSubject<User>(JSON.parse(localStorage.getItem('user')));
    this.user = this.userSubject.asObservable();
    this.httpOptions.headers.append('username', this.userValue.username) ;
  }
  getUsers() {
    return this.http.get(this.usersUrl);
  }

  login(username: string, password: string) {
    return this.http.get<User>(this.usersUrl + '?username=' + username + '&password=' + password)
      .pipe(map(user => {
        // store user details and jwt token in local storage to keep user logged in between page refreshes
        localStorage.setItem('user', JSON.stringify(user));
        this.userSubject.next(user);
        console.log(JSON.stringify(user) + 'usre from srvice in itrationfrom login...' + user);
        return user;
      }));
  }
  logout() {
    // remove user from local storage and set current user to null
    localStorage.removeItem('user');
    this.userSubject.next(null);
    this.router.navigate(['/login']);
  }

  public get userValue(): User {
    return this.userSubject.value;
  }

  getByUserId(username: string) {
    return this.http.get<User>(this.usersUrl + '?username=' + username);
  }


  register(user: User) {
    return this.http.post<User>(this.usersUrl, user, this.httpOptions);
  }
  delete(user: any) {
    console.log('from servic', user);
    const id = user.id;
    return this.http.delete(`${this.usersUrl}/${id}`)
      .pipe(map(x => {
        // auto logout if the logged in user deleted their own record
        if (user.username === this.userValue.username) {
          this.logout();
        }
        return x;
      }));
  }

  update(id: string, name: string, params: User) {
    return this.http.put(`${this.usersUrl}/${id}`, params)
      .pipe(map(x => {
        console.log('x from service updte', x);
        // update stored user if the logged in user updated their own record
        if (name === this.userValue.username) {
          // update local storage
          const user = { ...this.userValue, ...params };
          localStorage.setItem('user', JSON.stringify(user));

          // publish updated user to subscribers
          this.userSubject.next(user);
        }
        return x;
      }));
  }
}
