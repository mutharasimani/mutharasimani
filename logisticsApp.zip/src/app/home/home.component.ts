import { Component } from '@angular/core';
import { UserService } from '../service/user.service';
import { User } from '../models/user';


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent {

  user: User;

  constructor(private userService: UserService) {
    this.user = (this.userService.userValue)[0];
  }

}
