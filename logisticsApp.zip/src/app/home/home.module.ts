import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

import { AccountRoutingModule } from './account.routing.module';
import { MaterialModule } from '../material.module';
import { UserListComponent } from './user-list/user-list.component';
import { UserDetailsComponent } from './user-details/user-details.component';

@NgModule({
    imports: [
        CommonModule,
        ReactiveFormsModule,
        AccountRoutingModule, MaterialModule
    ],
    declarations: [
        UserListComponent, UserDetailsComponent
    ]
})
export class AccountModule { }
