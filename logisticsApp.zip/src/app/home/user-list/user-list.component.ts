import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router, Params } from '@angular/router';
import { UserService } from '../../service/user.service';
import { User } from '../../models/user';
import { first } from 'rxjs/operators';

@Component({
  selector: 'app-user-list',
  templateUrl: './user-list.component.html',
  styleUrls: ['./user-list.component.css']
})
export class UserListComponent implements OnInit {
  user: User;
  usersList: any[] = [];
  constructor(private userService: UserService, private route: ActivatedRoute, private router: Router) {
    this.user = (this.userService.userValue)[0];

  }
  ngOnInit() {
    this.getUsers();
  }

  getUsers() {
    if (this.user.isAdmin) {
      this.userService.getUsers().subscribe(
        (users: any) => this.usersList = users,
        err => console.log(err)
      );
    }
    else {
      this.usersList.push(this.user);
    }

  }

  deleteUser(user: any) {
    console.log('from ts', user);

    this.userService.delete(user)
      .pipe(first())
      .subscribe(() => {
        this.usersList = this.usersList.filter(x => x.id !== user.id);
      });
  }

}
