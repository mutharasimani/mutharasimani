import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { UserService } from '../../service/user.service';

import { ActivatedRoute, Router, Params } from '@angular/router';
import { first } from 'rxjs/operators';
@Component({
    selector: 'app-user-details',
    templateUrl: './user-details.component.html',
    styleUrls: ['./user-details.component.css']
})
export class UserDetailsComponent implements OnInit {
    returnUrl: string;
    username: string;
    isAddMode: boolean;
    recordId: string;
    isAdmin: boolean;
    userForm: FormGroup = new FormGroup({
        username: new FormControl('', [Validators.required]),
        firstName: new FormControl('', [Validators.required]),
        lastName: new FormControl('', [Validators.required]),
        password: new FormControl('', [Validators.required]),
        isAdmin: new FormControl('')
    });

    constructor(private userService: UserService, private route: ActivatedRoute, private router: Router) { }
    ngOnInit() {
        this.username = this.route.snapshot.params.username;
        console.log('this.username...' + this.username);

        this.isAddMode = !this.username;

        // password not required in edit mode
        if (this.isAddMode) {
            this.userForm.controls.password.setValidators([Validators.required, Validators.minLength(6)]);
        }
        else {
            this.userForm.controls.password.setValidators([Validators.minLength(6)]);
            this.userForm.controls.username.disable();
        }
        console.log('add...', this.isAddMode);
        if (!this.isAddMode) {
            this.userService.getByUserId(this.username)
                .subscribe(x => {
                    this.recordId = x[0].id;
                    this.f.firstName.setValue(x[0].firstName);
                    this.f.lastName.setValue(x[0].lastName);
                    this.f.username.setValue(x[0].username);
                    this.f.password.setValue(x[0].password);
                    this.f.isAdmin.setValue(x[0].isAdmin);
                });
        }
    }
    get f() { return this.userForm.controls; }

    submit() {

        if (this.userForm.invalid) {
            return;
        }

        if (this.isAddMode) {
            this.createUser();
        } else {
            this.updateUser();
        }

    }

    private createUser() {
        console.log(this.f.isAdmin.value + 'rr...' + this.f.password.value);
        console.log(JSON.stringify(this.userForm.value) + 'adduser' + this.userForm.value);
        const newUser: any = {
            username: this.f.username.value,
            password: this.f.password.value,
            firstName: this.f.firstName.value,
            lastName: this.f.lastName.value,
            isAdmin: this.f.isAdmin.value

        };
        this.userService.register(newUser)
            .pipe(first())
            .subscribe(
                data => {
                    this.router.navigate(['\home']);
                },
                error => {
                    console.log('error in create user');
                });
    }

    private updateUser() {
        const newUser: any = {
            username: this.f.username.value,
            password: this.f.password.value,
            firstName: this.f.firstName.value,
            lastName: this.f.lastName.value,
            isAdmin: this.f.isAdmin.value

        };
        this.userService.update(this.recordId, this.username, newUser)
            .pipe(first())
            .subscribe(
                data => {
                    this.router.navigate(['\home']);
                },
                error => {
                    console.log('error in update user');
                });
    }

}
